% Parameters of the Six-phase Asymmetric Induction Machine
% Predictive Current Control (PCC)
% Author: Aldo A. Aguilera
% Laboratorio de Sistemas de Potencia y Control (LSPyC)
% Update: 07-09-2025
% Control de Corriente Clasico (Pre-Falta y Post-Falta) con Falla en la Fase A con Neutros Acoplados (1N)

clear;
close all;
clc;

%%%%%%%%%%%%%%%%% VARIABLES GLOBALES %%%%%%%%%%%%%%%%%%%%%%%

global  Rs Rr Lls Llr Lm P M Lr Ls  v  Bm J Vdc K C invC  c1 c2 c3 c4 c5 TL XI c Ts XIf c0 Cf Kf vf invCf In 

%%%%%%%%%%%%%%% PARAMETROS DE LA MAQUINA %%%%%%%%%%%%%%%%%%%

Rs  = 6.7;               % (Omh) Resistencia del Estator.
Rr  = 6.9;               % (Omh) Resistencia del Rotor.

Llsxy = 0.00526;         % (H)
Lls = 0.00526+0.03512;   % (H) Inductancia de Fuga del Estator.
Llr	= 0.0128;            % (H) Inductancia de Fuga del Rotor.
Lm	= 0.614/3;           % (H) Inductancia de Magnetizacion.

M = 3*Lm;                % (H) Transformación de Inductancia Mutua (M=n/2*Lm), n=6.
Ls = Lls + M;            % (H) Inductancia Total del Estator.
Lr = Llr + M;            % (H) Inductancia Total del Rotor.

J  = 0.07;               % (Kg-m^2) Inercia Rotacional del Rotor.
Bm = 0.0004;             % (Nms/rad) Fricción Viscosa del Motor.
P = 1;                   % Pares de Polos.

% DC-link Voltage [V] 
Vdc = 300; %(V)

%%%%%%%%%%% PARAMETROS PARA LA SIMULACION %%%%%%%%%%%%%%%%%%%

simular = 5;              % (s) Tiempo de simulación.
Ts = 31.25e-6;            % (s) Tiempo de muestreo.
t_falta = 0;            % (s) Tiempo en el cual se produce la falla.
wref = 500*pi/30;         % (rad/s) Velocidad de referencia.
TL = 2;                   % (Nm) Torque de carga. % 1.5 en el original

%parametros para el controlador PI
ids_ref = 1;              % (A) Corriente 'd' de referencia
In = 7.5 ;                % (A) Corriente máxima (para el saturador )          In = 2.43;

% K_torque=P*M^2*ids_ref/Lr Control de Velocidad;
alpha_s = 1.5;
damping = 0.71;

%%%%%%%%%%%% PARAMETROS MODELO PREDICTIVO %%%%%%%%%%%%%%%%%%%

% Constantes del Modelo de Estado del motor
c1 = Ls*Lr-M^2;
c2 = Lr/c1;
c3 = M/c1;
c4 = Ls/c1;
c5 = 1/Lls;


%%%%%%%%%%%%%%%%%%% TABLAS DE COMBINACIONES PARA LOS DISPAROS %%%%%%%%%%%%%%%%%%%%%
     
         % 64 combinaciones de 6 bits. %
 XI = [ ...
        0     0     0     0     0     0
        0     0     0     0     0     1    %1
        0     0     0     0     1     0
        0     0     0     0     1     1
        0     0     0     1     0     0
        0     0     0     1     0     1
        0     0     0     1     1     0
        0     0     0     1     1     1
        0     0     1     0     0     0
        0     0     1     0     0     1
        0     0     1     0     1     0    %10
        0     0     1     0     1     1
        0     0     1     1     0     0
        0     0     1     1     0     1
        0     0     1     1     1     0
        0     0     1     1     1     1
        0     1     0     0     0     0
        0     1     0     0     0     1
        0     1     0     0     1     0
        0     1     0     0     1     1
        0     1     0     1     0     0     %20
        0     1     0     1     0     1
        0     1     0     1     1     0
        0     1     0     1     1     1
        0     1     1     0     0     0
        0     1     1     0     0     1
        0     1     1     0     1     0
        0     1     1     0     1     1
        0     1     1     1     0     0
        0     1     1     1     0     1
        0     1     1     1     1     0     %30
        0     1     1     1     1     1
        1     0     0     0     0     0
        1     0     0     0     0     1
        1     0     0     0     1     0
        1     0     0     0     1     1
        1     0     0     1     0     0
        1     0     0     1     0     1
        1     0     0     1     1     0
        1     0     0     1     1     1
        1     0     1     0     0     0     %40
        1     0     1     0     0     1
        1     0     1     0     1     0
        1     0     1     0     1     1
        1     0     1     1     0     0
        1     0     1     1     0     1
        1     0     1     1     1     0
        1     0     1     1     1     1
        1     1     0     0     0     0
        1     1     0     0     0     1
        1     1     0     0     1     0     %50
        1     1     0     0     1     1
        1     1     0     1     0     0
        1     1     0     1     0     1
        1     1     0     1     1     0
        1     1     0     1     1     1
        1     1     1     0     0     0
        1     1     1     0     0     1
        1     1     1     0     1     0
        1     1     1     0     1     1
        1     1     1     1     0     0     %60
        1     1     1     1     0     1
        1     1     1     1     1     0
        1     1     1     1     1     1];

       % 32 combinaciones de 5 bits. %
XIf = [ ...
         0     0     0     0     0
         0     0     0     0     1    %1
         0     0     0     1     0
         0     0     0     1     1
         0     0     1     0     0
         0     0     1     0     1
         0     0     1     1     0
         0     0     1     1     1
         0     1     0     0     0
         0     1     0     0     1
         0     1     0     1     0    %10
         0     1     0     1     1
         0     1     1     0     0
         0     1     1     0     1
         0     1     1     1     0
         0     1     1     1     1    %15
         1     0     0     0     0
         1     0     0     0     1
         1     0     0     1     0
         1     0     0     1     1
         1     0     1     0     0    %20
         1     0     1     0     1
         1     0     1     1     0
         1     0     1     1     1
         1     1     0     0     0
         1     1     0     0     1
         1     1     0     1     0
         1     1     0     1     1
         1     1     1     0     0
         1     1     1     0     1
         1     1     1     1     0     %30
         1     1     1     1     1  ];  
      
[c,n] = size(XI);
[c0,n1] = size(XIf);

%%%%%%%%%%%%%%%%%%% PARAMETROS DE LOS CONVERTIDORES %%%%%%%%%%%%%%%%%%%%%

% Matriz para el Calculo de Voltajes del Convertidor Para Neutros Acoplados

 K= (1/6)*[ 5   -1   -1   -1   -1   -1;
           -1    5   -1   -1   -1   -1;
           -1   -1    5   -1   -1   -1;
           -1   -1   -1    5   -1   -1;
           -1   -1   -1   -1    5   -1;
           -1   -1   -1   -1   -1    5 ] ;

% Matriz del Convertidor cuando Ocurre la Falla en (A) Para Neutros Acoplados

 Kf= (1/5)*[ 4   -1   -1   -1   -1;
            -1    4   -1   -1   -1;
            -1   -1    4   -1   -1;
            -1   -1   -1    4   -1;
            -1   -1   -1   -1    4 ] ;

%%%%%%%%%%%%%%%%%%%% MATRICES PARA LAS TRANSFORMADAS DE CLARKE INVARIANTE EN MODULO %%%%%%%%%%%%%%%%%%%%%

alpha = (2*pi)/3;   % 120 grados.

T6 =  [   1    cos(alpha)      cos(alpha)    sin(alpha)  -sin(alpha)      0
          0    sin(alpha)     -sin(alpha)   -cos(alpha)  -cos(alpha)     -1
          1    cos(alpha)      cos(alpha)   -sin(alpha)   sin(alpha)      0
          0   -sin(alpha)      sin(alpha)   -cos(alpha)  -cos(alpha)     -1
          1         1             1              0            0           0
          0         0             0              1            1           1   ];


C = (1/3)*T6;

invC = inv(C); 

% Matriz de Clarke post-falla (eliminando Ia y escalando)

k1 = 1;
k2 = 1;
Cf = C;             % Copia de la matriz Clarke original
Cf(:,1) = [];       % Elimina columna de la fase A (Ia = 0)
Cf(:,1:2) = Cf(:,1:2) * k1;  % Escala columnas B y C
Cf(:,3:5) = Cf(:,3:5) * k2;  % Escala columnas D, E y F


auxf0 = Cf;
auxf0(5, :) = [];  % Eliminar la fila 5 I0+
inv_auxf0= inv(auxf0);

% Inversa de Cf
auxf = Cf;
auxf(3, :) = [];  % Eliminar la fila 3 X
inv_auxf = inv(auxf);  

% Se Crea una nueva matriz (5x6)
newMatrix = zeros(5, 6);


% Reemplazamos las columnas de newMatrix :
newMatrix(:, 1) = inv_auxf(:, 1);  % Columna 1 de newMatrix = Columna 1 de inv_auxf
newMatrix(:, 2) = inv_auxf(:, 2);  % Columna 2 de newMatrix = Columna 2 de inv_auxf
newMatrix(:, 3) = inv_auxf0(:, 3); % Columna 3 de newMatrix = Columna 3 de inv_auxf0
newMatrix(:, 4) = inv_auxf(:, 3);  % Columna 4 de newMatrix = Columna 3 de inv_auxf
newMatrix(:, 5) = inv_auxf(:, 4);  % Columna 5 de newMatrix = Columna 4 de inv_auxf
newMatrix(:, 6) = inv_auxf(:, 5);  % Columna 6 de newMatrix = Columna 5 de inv_auxf

% Matriz Inversa Post Falta para representar las Fases.
invCf= newMatrix;

% Voltajes Pre y Post falta de Entradas U(t).
v =  Vdc*C*K*XI';
vf = Vdc*Cf*Kf*XIf';


