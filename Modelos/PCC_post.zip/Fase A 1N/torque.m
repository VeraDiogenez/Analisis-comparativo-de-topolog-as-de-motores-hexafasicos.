%% Funcion para calcular el Torque.
function[res]=torque(x)

global  P M 

% Corrientes del Rotor
iralfa=x(1);
irbeta=x(2);

% Corrientes del Estator
isalfa=x(3);
isbeta=x(4);

res=3*P*M*(iralfa*isbeta - irbeta*isalfa); % La Ecuacion que describe el torque es la misma pre y post falta. 