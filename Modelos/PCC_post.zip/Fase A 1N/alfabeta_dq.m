%% Funcion para la Transformada de PARK.
function[res]=alfabeta_dq(x)

% Corrientes ialfa-ibeta
ialfa=x(1);
ibeta=x(2);

% Angulo 𝜃 entre el eje 𝑎 y el eje 𝑑.                                                                                                  
theta=x(3);

% Matriz de rotación de 2D
D = [  cos(theta), sin(theta)
      -sin(theta), cos(theta)];

%Corrientes en el plano d-q
ialfaibeta = [ialfa;ibeta];
res = (D) * ialfaibeta;


