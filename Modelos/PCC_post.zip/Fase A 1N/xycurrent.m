%% Funcion Pre-Falta para las Corrientes X-Y (1N).
function[res]=xycurrent(x)
global  Rs c5

% Corrientes X-Y
isx=x(1);
isy=x(2);   

% Tensiones plano alfa-beta
vsalfa=x(3);
vsbeta=x(4);

% Tensiones plano x-y
vsx=x(5);
vsy=x(6);

% Tensiones de Secuencia 0+-
vsz1=x(7);
vsz2=x(8);

isxp=c5*(vsx - Rs*isx);
isyp=c5*(vsy - Rs*isy);

res=[isxp;isyp];