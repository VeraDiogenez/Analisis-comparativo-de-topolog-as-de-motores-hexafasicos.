%% Funcion Pre y Post Falta para las Corrientes de Secuencia 0+- (1N).
function[res]=zcurrent(x)
global  Rs c5

% Corrientes de Secuencia 0+-
isz1=x(1);
isz2=x(2); 

% Tensiones plano alfa-beta
vsalfa=x(3);
vsbeta=x(4);

% Tensiones plano x-y
vsx=x(5);
vsy=x(6);

% Tensiones de Secuencia 0+-
vsz1=x(7);
vsz2=x(8);

isz1p=c5*(vsz1 - Rs*isz1); %iz1=-iz2
isz2p=c5*(vsz2 - Rs*isz2);

res=[isz1p;isz2p];