%% Funcion para calcular el Deslizamiento
function[res]=deslizamiento(x)

global Rr Lr

id_ref=x(1);
iq_ref=x(2);

res= (iq_ref*Rr) / (Lr*id_ref);