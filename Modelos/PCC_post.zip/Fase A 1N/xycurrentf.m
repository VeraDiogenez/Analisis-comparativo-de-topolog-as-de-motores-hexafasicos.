%% Funcion Post-Falta para las Corrientes X-Y (1N).
function[res]=xycurrentf(x)
global  Rs c5

% Corrientes del Estator
isalfa=x(1);
isbeta=x(2);

% Corrientes X-Y
isx=x(3);
isy=x(4);

% Corrientes de Secuencia 0
isz1=x(5);
isz2=x(6);

% Tensiones plano alfa-beta
vsalfa=x(7);
vsbeta=x(8);

% Tensiones plano x-y
vsx=x(9);
vsy=x(10);

%Tensiones de Secuencia 0+-
vsz1=x(11);
vsz2=x(12);

isx =-(isalfa+isz1);
isyp= c5 * (vsy - Rs*isy);

res=[isx;isyp];