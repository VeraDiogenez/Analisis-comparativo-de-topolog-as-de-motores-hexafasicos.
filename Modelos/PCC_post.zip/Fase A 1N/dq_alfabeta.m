%% Funcion para la Transformada Inversa de Park.
function[res]=dq_alfabeta(x)

% Corrientes id-iq
id=x(1);
iq=x(2);

% Angulo 𝜃 entre el eje 𝑎 y el eje 𝑑.
theta=x(3);

% Matriz de rotación de 2D
D = [  cos(theta), sin(theta)
      -sin(theta), cos(theta)];

%Corrientes en el plano alfa-beta
idiq = [id;iq];
res = (D)^(-1) * idiq;


