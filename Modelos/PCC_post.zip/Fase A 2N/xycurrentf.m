%% Funcion Post-Falta para las Corrientes X-Y 2N.
function[res]=xycurrentf(x)

global  Rs c5

% Corrientes del Estator
isalfa=x(1);
isbeta=x(2);

% Corrientes X-Y
isx=x(3);
isy=x(4); 

%Tensiones plano alfa-beta
vsalfa=x(5);
vsbeta=x(6);

%Tensiones plano x-y
vsx=x(7);
vsy=x(8);

%Tensiones de Secuencia 0+-
vsz1=x(9);
vsz2=x(10);

% isxp =c5 * (vsx - Rs*isx);
isx = -isalfa;
isyp= c5 * (vsy - Rs*isy);

res=[isx;isyp];