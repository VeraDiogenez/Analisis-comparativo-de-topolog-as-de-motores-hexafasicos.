function[res]=xycurrent(x)

global  Rs c5
        
%%Tensiones de fase
vsalfa=x(1);
vsbeta=x(2);
vsx=x(3);
vsy=x(4);
vsz1=x(5);
vsz2=x(6);

isx=x(7);
isy=x(8);


isxp=c5*(vsx - Rs*isx);
isyp=c5*(vsy - Rs*isy);

res=[isxp;isyp];