function[res]=statorcurrentf(x)

global  Rs Rr M Lr c2 c3 

% Corrientes del estator
isalfa=x(1);
isbeta=x(2);

% Corrientes del rotor
iralfa=x(3);
irbeta=x(4);

% Tensiones plano alfa-beta
vsalfa=x(5);
vsbeta=x(6);

% Tensiones plano x-y
vsx=x(7);
vsy=x(8);

% Tensiones de secuencia 0+-
vsz1=x(9);
vsz2=x(10);

% Velocidad Electrica del giro del Rotor
wr=x(11);

% 5 Fases
%isalfap=c2*(vsalfa - Rs*isalfa) + c3*(Rr*iralfa + wr*irbeta*Lr + wr*isbeta*M);
%isbetap=c2*(vsbeta - Rs*isbeta) + c3*(Rr*irbeta - wr*iralfa*Lr - wr*isalfa*M);

% 6 Fases (no var�a al de 5 fases)
isalfap=c2*(vsalfa - Rs*isalfa) + c3*(Rr*iralfa + wr*irbeta*Lr + wr*isbeta*M);
isbetap=c2*(vsbeta - Rs*isbeta) + c3*(Rr*irbeta - wr*iralfa*Lr - wr*isalfa*M);

res=[isalfap;isbetap];