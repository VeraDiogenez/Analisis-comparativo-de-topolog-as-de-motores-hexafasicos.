function[res]=rotorcurrent(x)

global  Rs Rr M Lr c3 c4 

% Corrientes del estator
isalfa=x(1);
isbeta=x(2);

% Corrientes del rotor
iralfa=x(3);
irbeta=x(4);

% Tensiones plano alfa-beta
vsalfa=x(5);
vsbeta=x(6);

% Tensiones plano x-y
vsx=x(7);
vsy=x(8);

% Tensiones de secuencia 0+-
vsz1=x(9);
vsz2=x(10);

% Velocidad electrica
wr=x(11);


% 6 Fases
% iralfap=c3*(-vsalfa + Rs*isalfa) + c4*(-Rr*iralfa - wr*irbeta*Lr - wr*isbeta*M);
% irbetap=c3*(-vsbeta + Rs*isbeta) + c4*(-Rr*irbeta + wr*iralfa*Lr + wr*isalfa*M);

% 5 Fases (no var�a al de 6 fases)
iralfap=c3*(-vsalfa + Rs*isalfa) + c4*(-Rr*iralfa - wr*irbeta*Lr - wr*isbeta*M);
irbetap=c3*(-vsbeta + Rs*isbeta) + c4*(-Rr*irbeta + wr*iralfa*Lr + wr*isalfa*M);

res=[iralfap;irbetap];